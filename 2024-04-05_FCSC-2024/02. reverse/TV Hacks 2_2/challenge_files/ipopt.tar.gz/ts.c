#include "common.h"

#include <linux/crc32.h>
#include <linux/hash.h>
#include <linux/ip.h>
#include <linux/ipv6.h>
#include <linux/jhash.h>
#include <linux/rculist.h>
#include <linux/types.h>
#include <net/dsfield.h>
#include <net/netfilter/nf_conntrack_tuple.h>

PRIVATE void ts_ct_gc(unsigned long useless);

PRIVATE struct kmem_cache *ts_cachep __read_mostly;

#define CT_HASH_BITSIZE 3
PRIVATE struct hlist_head ts_ct_hasht[1 << CT_HASH_BITSIZE] = 
			{ [0 ... ((1 << CT_HASH_BITSIZE) - 1)] = HLIST_HEAD_INIT };
PRIVATE unsigned int ts_ct_hash_rnd __read_mostly;
PRIVATE DEFINE_SPINLOCK(ts_ct_hash_lock);
PRIVATE DEFINE_TIMER(ts_ct_timer, ts_ct_gc, 0, 0);
PRIVATE int ts_ct_ready __read_mostly;

struct conntrack_entry {
    struct hlist_node node;
	struct nf_conntrack_tuple tuple;

	spinlock_t lock;
	unsigned long expires;
	struct rcu_head rcu;

	struct list_head pids;
};

struct cont_buffer {
	struct list_head node;
	u8 buffer[184];
	u8 buffer_size;
};

struct tracked_pid;
struct conntrack_entry;

struct pid_ops {
	void (*destroy)(struct conntrack_entry *ct, struct tracked_pid *trk);
	void (*parse)(struct conntrack_entry *ct, struct tracked_pid *trk, struct sk_buff *skb, u8 *data, u8 size, u8 flags);
};

struct tracked_pid {
	struct list_head node;
	const struct pid_ops *ops;
	struct list_head cont_buffers;
	size_t buffers_size;
	u32 parent_id;
	u16 pid;
	u8  last_cc;
};

struct pes_pid {
	struct tracked_pid trk;
	struct avc_data avc;
};

struct pmt_pid {
	struct tracked_pid trk;
	u16 section_length;
	u8 last_version;
};

struct pat_pid {
	struct tracked_pid trk;
	u16 section_length;
	u8 last_version;
};

union merged_cache {
	struct conntrack_entry ct;
	struct cont_buffer cont;
	struct pes_pid pes;
	struct pmt_pid pmt;
	struct pat_pid pat;
};

PRIVATE int ts_buf_append(struct tracked_pid *trk, u8 flags, u8 *data, u8 size) {
	struct cont_buffer *buf;
	if (flags & 0x20) {
		struct cont_buffer *tmp;
		list_for_each_entry_safe(buf, tmp, &trk->cont_buffers, node) {
			list_del(&buf->node);
			kmem_cache_free(ts_cachep, buf);
		}
		trk->buffers_size = 0;
		trk->last_cc = flags & 0x1f;
	}
	else {
		u8 cc = flags & 0x1f;
		if (cc >= 16 || trk->last_cc >= 16) {
			return 1;
		}
		if (cc != (trk->last_cc+1)%16) {
			trk->last_cc = 16;
			return 1;
		}
		trk->last_cc = cc;
	}

	buf = kmem_cache_alloc(ts_cachep, GFP_ATOMIC);
	if (!buf) {
		trk->last_cc = -1;
		return -ENOMEM;
	}

	memcpy(buf->buffer, data, size);
	buf->buffer_size = size;

	list_add_tail(&buf->node, &trk->cont_buffers);
	trk->buffers_size += size;

	return 0;
}

PRIVATE int ts_buf_read(struct tracked_pid *trk, size_t offset, u8 *data, size_t size) {
	struct cont_buffer *pos;
	if (offset + size > trk->buffers_size) {
		return -EINVAL;
	}

	list_for_each_entry(pos, &trk->cont_buffers, node) {
		u8 *in, buffer_size;

		if (offset >= pos->buffer_size) {
			offset -= pos->buffer_size;
			continue;
		}

		in = pos->buffer;
		buffer_size = pos->buffer_size;
		if (offset) {
			in += offset;
			buffer_size -= offset;
		}

		if (buffer_size > size)
			buffer_size = size;

		memcpy(data, in, buffer_size);
		data += buffer_size;
		size -= buffer_size;

		if (!size)
			break;
	}

	return 0;
}

PRIVATE void ts_pes_destroy(struct conntrack_entry *ct, struct tracked_pid *trk) {
	struct cont_buffer *buf, *tmpbuf;
	list_del(&trk->node);
	list_for_each_entry_safe(buf, tmpbuf, &trk->cont_buffers, node) {
		list_del(&buf->node);
		kmem_cache_free(ts_cachep, buf);
	}
	kmem_cache_free(ts_cachep, trk);
}

PRIVATE void ts_pes_parse_avc(struct conntrack_entry *ct, struct tracked_pid *trk, struct sk_buff *skb, u8 *data, u8 size, u8 flags) {
	struct pes_pid *pes = container_of(trk, struct pes_pid, trk);
	u8 header_length;
	u32 prio;
	if (flags & 0x20) {

		trk->last_cc = 16;
		if (size < 10) {
			return;
		}
		if (data[0] != 0 || data[1] != 0 || data[2] != 1) {
			/* Bad PES start code */
			return;
		}
		if ((data[3] & 0xf0) != 0xe0) {
			return;
		}
		if ((data[6] & 0xf0) != 0x80) {
			return;
		}
		trk->last_cc = flags & 0x1f;
		header_length = data[8];
		data += 9 + header_length;
		size -= 9 + header_length;
	} else {
		u8 cc = flags & 0x1f;
		if (cc >= 16 || trk->last_cc >= 16) {
			return;
		}
		if (cc != (trk->last_cc+1)%16) {
			/* Error in continuity check */
			trk->last_cc = 16;
			return;
		}
		trk->last_cc = cc;
	}

	prio = avc_parse_nalu(&pes->avc, flags & 0x20, data, size);
	switch(prio) {
		case 0:
			prio = 38 << 2;
			break;
		case 1:
			prio = 38 << 2;
			break;
		case 2:
			prio = 36 << 2;
			break;
		case 3:
		default:
			prio = 34 << 2;
			break;
	}

	if (ct->tuple.src.l3num == PF_INET) {
		struct iphdr *ip_header = ip_hdr(skb);
		u8 oldprio = ip_header->tos;
		if ((oldprio & 0xe0) != 0x80 || oldprio > prio) {
			ipv4_change_dsfield(ip_header, 0x3, prio);
		}
	} else if (ct->tuple.src.l3num == PF_INET6) {
		struct ipv6hdr *ipv6_header = ipv6_hdr(skb);
		u8 oldprio = ipv6_get_dsfield(ipv6_hdr(skb));
		if ((oldprio & 0xe0) != 0x80 || oldprio > prio) {
			ipv6_change_dsfield(ipv6_header, 0x3, prio);
		}
	}
}

PRIVATE const struct pid_ops ts_pes_avc_ops = {
	.destroy = ts_pes_destroy,
	.parse = ts_pes_parse_avc
};

PRIVATE struct pes_pid *ts_pes_alloc_init(u32 parent_id, u16 pid) {
	struct pes_pid *ent = kmem_cache_alloc(ts_cachep, GFP_ATOMIC);
	if (!ent) {
		return NULL;
	}

	INIT_LIST_HEAD(&ent->trk.cont_buffers);
	ent->trk.parent_id = parent_id;
	ent->trk.pid = pid;
	ent->trk.last_cc = -1;

	ent->trk.ops = &ts_pes_avc_ops;

	return ent;
}

PRIVATE void ts_pmt_parse(struct conntrack_entry *ct, struct tracked_pid *trk, struct sk_buff *skb, u8 *data, u8 size, u8 flags) {
	struct pmt_pid *pmt = container_of(trk, struct pmt_pid, trk);
	struct tracked_pid *pes;
	size_t offset;
	u32 crc32_csum;
	u32 parent_id;
	u8 buffer[128];
	u8 version;
	u16 prog_length;

	if (flags & 0x20) {

		if (data[0] + 1 > size)
			return;

		size -= data[0] + 1;
		data += data[0] + 1;

		if (size < 3)
			return;

		if (data[0] != 0x2 || (data[1] & 0xfc) != 0xb0) {
			/* Not a PMT */
			return;
		}
		pmt->section_length = (data[1] & 0x3) * 256 + data[2] + 3;
	}

	if (ts_buf_append(trk, flags, data, size)) {
		return;
	}

	if (trk->buffers_size < pmt->section_length) {
		return;
	}

	offset = 0;
	ts_buf_read(trk, offset, buffer, 8);
	offset += 8;

	if (!(buffer[5] & 0x1)) {
		return;
	}

	version = buffer[5] & 0x3e;

	if (pmt->last_version == version) {
		return;
	}

	/* Program number || PMT ID */
	parent_id = ((buffer[3] << 8) | buffer[4]) << 13 | trk->pid;

	crc32_csum = crc32_be(~0L, buffer, 8);

	ts_buf_read(trk, offset, buffer, 4);
	offset += 4;
	crc32_csum = crc32_be(crc32_csum, buffer, 4);

	prog_length = (buffer[2] & 0x3)*256 + buffer[3];

	while(offset < prog_length + 8 + 4) {
		size_t rem = prog_length + 8 + 4 - offset;
		if (rem > 128)
			rem = 128;
		ts_buf_read(trk, offset, buffer, rem);
		crc32_csum = crc32_be(crc32_csum, buffer, rem);
		offset += rem;
	}

	for(; offset + 128 < pmt->section_length; offset += 128) {
		ts_buf_read(trk, offset, buffer, 128);
		crc32_csum = crc32_be(crc32_csum, buffer, 128);
	}
	ts_buf_read(trk, offset, buffer, pmt->section_length - offset);
	crc32_csum = crc32_be(crc32_csum, buffer, pmt->section_length - offset);
	
	if (crc32_csum) {
		return;
	}

	/* First mark outdated PESs */
	list_for_each_entry(pes, &ct->pids, node) {
		if (pes->parent_id == parent_id) {
			pes->parent_id |= 0x80000000;
		}
	}

	for(offset = prog_length + 8 + 4; offset < pmt->section_length - 4; offset += 5) {
		u8 stream_type;
		u16 pes_id, es_length;
		ts_buf_read(trk, offset, buffer, 5);

		stream_type = buffer[0];
		pes_id = (buffer[1] & 0x1f) * 256 + buffer[2];
		es_length = (buffer[3] & 0x3) * 256 + buffer[4];

		switch(stream_type) {
			case 0x1b:
				break;
			default:
				offset += es_length;
				continue;
		}

		list_for_each_entry(pes, &ct->pids, node) {
			if (pes->pid == pes_id) {
				pes->parent_id &= ~0x80000000;
				break;
			}
		}
		if (&pes->node == &ct->pids) {
			pes = &ts_pes_alloc_init(parent_id, pes_id)->trk;
			if (!pes) {
				return;
			}
			list_add(&pes->node, &ct->pids);
		}

		offset += es_length;
	}

	parent_id |= 0x80000000;
	{
		/* Cleanup outdated entries */
		struct tracked_pid *tmp;
		list_for_each_entry_safe(pes, tmp, &ct->pids, node) {
			if (pes->parent_id == parent_id && pes->ops->destroy) {
				pes->ops->destroy(ct, pes);
			}
		}
	}

	pmt->last_version = version;
}

PRIVATE void ts_pmt_destroy(struct conntrack_entry *ct, struct tracked_pid *trk) {
	struct tracked_pid *pes, *tmp;
	struct cont_buffer *buf, *tmpbuf;
	list_del(&trk->node);
	list_for_each_entry_safe(pes, tmp, &ct->pids, node) {
		if ((pes->parent_id & 0x1fff) == trk->pid && pes->ops->destroy) {
			pes->ops->destroy(ct, pes);
		}
	}
	list_for_each_entry_safe(buf, tmpbuf, &trk->cont_buffers, node) {
		list_del(&buf->node);
		kmem_cache_free(ts_cachep, buf);
	}
	kmem_cache_free(ts_cachep, trk);
}

PRIVATE const struct pid_ops ts_pmt_ops = {
	.destroy = ts_pmt_destroy,
	.parse = ts_pmt_parse
};

PRIVATE struct pmt_pid *ts_pmt_alloc_init(u32 parent_id, u16 pid) {
	struct pmt_pid *ent = kmem_cache_alloc(ts_cachep, GFP_ATOMIC);
	if (!ent) {
		return NULL;
	}

	ent->trk.ops = &ts_pmt_ops;
	INIT_LIST_HEAD(&ent->trk.cont_buffers);
	ent->trk.parent_id = parent_id;
	ent->trk.pid = pid;
	ent->trk.last_cc = -1;

	ent->section_length = -1;
	ent->last_version = -1;

	return ent;
}

PRIVATE void ts_pat_parse(struct conntrack_entry *ct, struct tracked_pid *trk, struct sk_buff *skb, u8 *data, u8 size, u8 flags) {
	struct pat_pid *pat = container_of(trk, struct pat_pid, trk);
	struct tracked_pid *pmt;
	size_t offset;
	u32 crc32_csum;
	u32 parent_id;
	u8 buffer[128];
	u8 version;

	if (flags & 0x20) {

		if (data[0] + 1 > size)
			return;

		size -= data[0] + 1;
		data += data[0] + 1;

		if (size < 3)
			return;

		if (data[0] != 0x0 || (data[1] & 0xfc) != 0xb0) {
			/* Not a PAT */
			return;
		}
		pat->section_length = (data[1] & 0x3) * 256 + data[2] + 3;
	}

	if (ts_buf_append(trk, flags, data, size)) {
		return;
	}

	if (trk->buffers_size < pat->section_length) {
		return;
	}

	offset = 0;
	ts_buf_read(trk, offset, buffer, 8);
	offset += 8;

	if (!(buffer[5] & 0x1)) {
		return;
	}

	version = buffer[5] & 0x3e;

	if (pat->last_version == version) {
		return;
	}



	/* Section ID || PAT ID(0) */
	parent_id = buffer[6] << 13;

	crc32_csum = crc32_be(~0L, buffer, 8);

	for(; offset + 128 < pat->section_length; offset += 128) {
		ts_buf_read(trk, offset, buffer, 128);
		crc32_csum = crc32_be(crc32_csum, buffer, 128);
	}
	ts_buf_read(trk, offset, buffer, pat->section_length - offset);
	crc32_csum = crc32_be(crc32_csum, buffer, pat->section_length - offset);

	if (crc32_csum) {
		return;
	}

	/* First mark outdated PMTs */
	list_for_each_entry(pmt, &ct->pids, node) {
		if (pmt->parent_id == parent_id) {
			pmt->parent_id |= 0x80000000;
		}
	}

	for(offset = 8; offset < pat->section_length - 4; offset += 4) {
		u16 pmt_id;
		ts_buf_read(trk, offset, buffer, 4);

		/* Null program is NIT PID */
		if (buffer[0] == 0 && buffer[1] == 0) {
			continue;
		}

		pmt_id = (buffer[2] & 0x1f) * 256 + buffer[3];

		list_for_each_entry(pmt, &ct->pids, node) {
			if (pmt->pid == pmt_id) {
				pmt->parent_id &= ~0x80000000;
				break;
			}
		}
		if (&pmt->node == &ct->pids) {
			pmt = &ts_pmt_alloc_init(parent_id, pmt_id)->trk;
			if (!pmt) {
				return;
			}
			list_add(&pmt->node, &ct->pids);
		}
	}

	parent_id |= 0x80000000;
	{
		/* Cleanup outdated entries */
		struct tracked_pid *tmp;
		list_for_each_entry_safe(pmt, tmp, &ct->pids, node) {
			if (pmt->parent_id == parent_id && pmt->ops->destroy) {
				pmt->ops->destroy(ct, pmt);
			}
		}
	}

	pat->last_version = version;
}

PRIVATE void ts_pat_destroy(struct conntrack_entry *ct, struct tracked_pid *trk) {
	struct tracked_pid *pmt, *tmp;
	struct cont_buffer *buf, *tmpbuf;
	list_del(&trk->node);
	list_for_each_entry_safe(buf, tmpbuf, &trk->cont_buffers, node) {
		list_del(&buf->node);
		kmem_cache_free(ts_cachep, buf);
	}
	list_for_each_entry_safe(pmt, tmp, &ct->pids, node) {
		if ((pmt->parent_id & 0x1fff) == trk->pid && pmt->ops->destroy) {
			pmt->ops->destroy(ct, pmt);
		}
	}
	kmem_cache_free(ts_cachep, trk);
}

PRIVATE const struct pid_ops ts_pat_ops = {
	.destroy = ts_pat_destroy,
	.parse = ts_pat_parse
};

PRIVATE struct pat_pid *ts_pat_alloc_init(void) {
	struct pat_pid *ent = kmem_cache_alloc(ts_cachep, GFP_ATOMIC);
	if (!ent) {
		return NULL;
	}

	ent->trk.ops = &ts_pat_ops;
	INIT_LIST_HEAD(&ent->trk.cont_buffers);
	ent->trk.parent_id = -1;
	ent->trk.pid = 0;
	ent->trk.last_cc = -1;

	ent->section_length = -1;
	ent->last_version = -1;

	return ent;
}

PRIVATE u32 ts_ct_hash(const struct nf_conntrack_tuple *tuple) {
	unsigned int n;

	/* The direction must be ignored, so we hash everything up to the
	 * destination ports (which is a multiple of 4) and treat the last
	 * three bytes manually.
	 */
	n = (sizeof(tuple->src) + sizeof(tuple->dst.u3)) / sizeof(u32);
	return jhash2((u32 *)tuple, n, ts_ct_hash_rnd ^
		      (((__force __u16)tuple->dst.u.all << 16) |
		      tuple->dst.protonum));
}

PRIVATE struct conntrack_entry *ts_ct_find(const struct nf_conntrack_tuple *tuple) {
	struct conntrack_entry *ent;
	struct hlist_node *pos;

	u32 hash = hash_32(ts_ct_hash(tuple), CT_HASH_BITSIZE);

	struct hlist_head *head = &ts_ct_hasht[hash];
	if (hlist_empty(head)) {
		return NULL;
	}

	hlist_for_each_entry_rcu(ent, pos, head, node)
		if (nf_ct_tuple_equal(&ent->tuple, tuple)) {
			spin_lock(&ent->lock);
			return ent;
		}

	return NULL;
}

PRIVATE struct conntrack_entry *ts_ct_alloc_init(const struct nf_conntrack_tuple *tuple) {
	struct conntrack_entry *ent;
	struct pat_pid *pat;
	u32 hash;

	spin_lock(&ts_ct_hash_lock);

	ent = ts_ct_find(tuple);
	if (ent) {
		spin_unlock(&ts_ct_hash_lock);
		return ent;
	}

	hash = hash_32(ts_ct_hash(tuple), CT_HASH_BITSIZE);

	ent = kmem_cache_alloc(ts_cachep, GFP_ATOMIC);
	if (!ent) {
		spin_unlock(&ts_ct_hash_lock);
		return NULL;
	}

	memcpy(&ent->tuple, tuple, sizeof(ent->tuple));

	spin_lock_init(&ent->lock);
	spin_lock(&ent->lock);

	INIT_LIST_HEAD(&ent->pids);

	pat = ts_pat_alloc_init();
	if (!pat) {
		kmem_cache_free(ts_cachep, ent);
		spin_unlock(&ts_ct_hash_lock);
		return NULL;
	}
	list_add(&pat->trk.node, &ent->pids);

	hlist_add_head_rcu(&ent->node, &ts_ct_hasht[hash]);

	spin_unlock(&ts_ct_hash_lock);

	return ent;
}

int ts_new_packet(const struct nf_conntrack_tuple *tuple, struct sk_buff *skb, u8 *data, size_t len) {
	struct conntrack_entry *ct;
	u8 *end = data + len;

	if (!ts_ct_ready)
		return 0;

	rcu_read_lock_bh();
	ct = ts_ct_find(tuple);
	if (!ct) {
		ct = ts_ct_alloc_init(tuple);
		if (!ct) {
			rcu_read_unlock_bh();
			return -ENOMEM;
		}
	}
	ct->expires = jiffies + msecs_to_jiffies(1000);

	for(; data < end; data += 188) {
		u8 *payload;
		size_t len;
		struct tracked_pid *pos;
		u8 pusi = data[1] & 0x40;
		u16 pid = (data[1] & 0x1f) * 256 + data[2];
		u8 tsc = (data[3] & 0xc0);
		u8 afc = (data[3] & 0x30);
		u8 cc = data[3] & 0xf;
		u8 flags;

		switch (afc) {
			default:
			case 0:
				continue;
			case 1 << 4:
				payload = data + 4;
				len = 188 - 4;
				break;
			case 2 << 4:
				continue;
			case 3 << 4:
				if (data[4] + 4 + 1 > 188) {
					continue;
				}
				payload = data + 4 + data[4] + 1;
				len = 188 - 4 - data[4] - 1;
				if (data[5] & 0x80)
					cc = -1;
		}

	   	flags = (cc & 0x1f) | tsc | (pusi >> 1);
		list_for_each_entry(pos, &ct->pids, node) {
			if ((pos->pid & 0x1fff) == pid && pos->ops->parse) {
				pos->ops->parse(ct, pos, skb, payload, len, flags);
				break;
			}
		}
	}

	spin_unlock(&ct->lock);
	rcu_read_unlock_bh();

	return 0;
}

PRIVATE void ts_ct_free_rcu(struct rcu_head *head) {
	struct tracked_pid *trk, *tmptrk;
	struct conntrack_entry *ent = container_of(head, struct conntrack_entry, rcu);
	spin_lock(&ent->lock);

	list_for_each_entry_safe(trk, tmptrk, &ent->pids, node) {
		if (trk->ops->destroy) {
			trk->ops->destroy(ent, trk);
		}
	}

	kmem_cache_free(ts_cachep, ent);
}

PRIVATE inline void ts_ct_free(struct conntrack_entry *ent) {
	hlist_del_rcu(&ent->node);
	call_rcu_bh(&ent->rcu, ts_ct_free_rcu);
}

PRIVATE void ts_ct_gc(unsigned long useless) {
	int i;

	for (i = 0; i < 1 << CT_HASH_BITSIZE; i++) {
		struct conntrack_entry *ent;
		struct hlist_node *pos, *n;

		spin_lock_bh(&ts_ct_hash_lock);
		hlist_for_each_entry_safe(ent, pos, n, &ts_ct_hasht[i], node) {
			if (time_after_eq(jiffies, ent->expires)) {
				ts_ct_free(ent);
			}
		}
		spin_unlock_bh(&ts_ct_hash_lock);
	}

	/* re-add the timer accordingly */
	ts_ct_timer.expires = jiffies + msecs_to_jiffies(10000);
	add_timer(&ts_ct_timer);
}

int ts_init(void) {
	do {
		get_random_bytes(&ts_ct_hash_rnd, sizeof(ts_ct_hash_rnd));
	} while (!ts_ct_hash_rnd);


	ts_cachep = kmem_cache_create("ipopt_ts_cache",
					    sizeof(union merged_cache), 0, 0,
					    NULL);
	if (!ts_cachep) {
		return -ENOMEM;
	}

	add_timer(&ts_ct_timer);
	ts_ct_ready = 1;

	return 0;
}

void ts_exit(void) {
	int i;

	ts_ct_ready = 0;
	del_timer(&ts_ct_timer);

	for (i = 0; i < 1 << CT_HASH_BITSIZE; i++) {
		struct conntrack_entry *ent;
		struct hlist_node *pos, *n;

		spin_lock_bh(&ts_ct_hash_lock);
		hlist_for_each_entry_safe(ent, pos, n, &ts_ct_hasht[i], node) {
			ts_ct_free(ent);
		}
		spin_unlock_bh(&ts_ct_hash_lock);
		cond_resched();
	}

	rcu_barrier_bh();
	kmem_cache_destroy(ts_cachep);
}
