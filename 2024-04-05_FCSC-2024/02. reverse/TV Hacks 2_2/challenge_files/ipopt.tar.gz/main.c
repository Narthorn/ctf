#include "common.h"

#include <linux/init.h>
#include <linux/ip.h>
#include <linux/ipv6.h>
#include <linux/mod_devicetable.h>
#include <linux/module.h>
#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h>
#include <linux/netfilter_ipv6.h>
#include <linux/kernel.h>
#include <net/ip.h>
#include <net/netfilter/nf_conntrack_tuple.h>

#if !defined(CONFIG_NETFILTER)
#error "Nothing to do"
#endif

PRIVATE inline int check_magic(u32 magic) {
	magic = ntohl(magic);
	return (magic & 0xff8000c0) == 0x47000000;
}

PRIVATE inline int check_len(size_t pkt_len) {
	return (pkt_len % 188) == 8;
}

PRIVATE unsigned int ipopt_ip_postroute(unsigned int hooknum,
					   struct sk_buff *skb,
					   const struct net_device *in,
					   const struct net_device *out,
					   int (*okfn)(struct sk_buff *),
					   u16 family)
{
    struct udphdr *udp_header;
	struct nf_conntrack_tuple tuple;
	size_t pkt_len;
    u32 *data, *end;
	loff_t offset;

	if (!skb) {
		return NF_ACCEPT;
	}

	memset(&tuple, 0, sizeof(tuple));

	if (family == PF_INET) {
		struct iphdr *ip_header = ip_hdr(skb);
		if (skb_headlen(skb) < sizeof(*ip_header)) {
			return NF_ACCEPT;
		}
		if (!ip_header || ip_header->protocol != IPPROTO_UDP) {
			return NF_ACCEPT;
		}
		offset = ip_hdrlen(skb);
		pkt_len = ntohs(ip_header->tot_len) - offset;

		tuple.src.l3num = PF_INET;
		tuple.src.u3.ip = ip_header->saddr;
		tuple.dst.u3.ip = ip_header->daddr;
	} else if (family == PF_INET6) {
		struct ipv6hdr *ipv6_header = ipv6_hdr(skb);
		if (skb_headlen(skb) < sizeof(*ipv6_header)) {
			return NF_ACCEPT;
		}
		if (!ipv6_header || ipv6_header->nexthdr != IPPROTO_UDP) {
			return NF_ACCEPT;
		}
		offset = sizeof(*ipv6_header);
		pkt_len = ntohs(ipv6_header->payload_len);
		tuple.src.l3num = PF_INET6;
		memcpy(tuple.src.u3.ip6, &ipv6_header->saddr, sizeof(tuple.src.u3.ip6));
		memcpy(tuple.dst.u3.ip6, &ipv6_header->daddr, sizeof(tuple.dst.u3.ip6));
	} else {
		return NF_ACCEPT;
	}

	if (pkt_len < sizeof(struct udphdr) + sizeof(u32)) {
		return NF_ACCEPT;
	}
	if (!pskb_may_pull(skb, offset + sizeof(struct udphdr) + sizeof(u32))) {
		return NF_ACCEPT;
	}

	data = (u32 *)(skb_network_header(skb) + offset);

	if (!check_magic(data[sizeof(struct udphdr)/sizeof(*data)])) {
		return NF_ACCEPT;
	}

	if (!check_len(pkt_len)) {
		return NF_ACCEPT;
	}

	if (!skb_make_writable(skb, offset + pkt_len)) {
		return NF_ACCEPT;
	}

	udp_header = (struct udphdr *)(skb_network_header(skb) + offset);

	offset += sizeof(*udp_header);
	pkt_len -= sizeof(*udp_header);

	data = (u32 *)(skb_network_header(skb) + offset) + 188/sizeof(*data) + 1;
	end = (u32 *)(skb_network_header(skb) + offset + pkt_len);

	while (data < end) {
		if (!check_magic(data[-1])) {
			return NF_ACCEPT;
		}
		data += 188/sizeof(*data);
	}

	data = (u32 *)(skb_network_header(skb) + offset);

	tuple.src.u.udp.port = udp_header->source;
	tuple.dst.u.udp.port = udp_header->dest;

	ts_new_packet(&tuple, skb, (u8 *)data, pkt_len);

	return NF_ACCEPT;
}

PRIVATE unsigned int ipopt_ip4_postroute(unsigned int hooknum,
					   struct sk_buff *skb,
					   const struct net_device *in,
					   const struct net_device *out,
					   int (*okfn)(struct sk_buff *))
{
	return ipopt_ip_postroute(hooknum, skb, in, out, okfn, PF_INET);
}

PRIVATE unsigned int ipopt_ip6_postroute(unsigned int hooknum,
					   struct sk_buff *skb,
					   const struct net_device *in,
					   const struct net_device *out,
					   int (*okfn)(struct sk_buff *))
{
	return ipopt_ip_postroute(hooknum, skb, in, out, okfn, PF_INET6);
}

PRIVATE struct nf_hook_ops ipopt_nf_ops[] = {
	{
		.hook =		ipopt_ip4_postroute,
		.pf =		NFPROTO_IPV4,
		.hooknum =	NF_INET_POST_ROUTING,
		.priority =	NF_IP_PRI_LAST - 1,
	},
#if IS_ENABLED(CONFIG_IPV6) || defined(CONFIG_IPV6_MODULE)
	{
		.hook =		ipopt_ip6_postroute,
		.pf =		NFPROTO_IPV6,
		.hooknum =	NF_INET_POST_ROUTING,
		.priority =	NF_IP6_PRI_LAST - 1,
	},
#endif	/* IPV6 */
};

PRIVATE int __init ipopt_module_init(void) {
	int err;
	err = ts_init();
	if (err)
		goto after_nothing;

	err = nf_register_hooks(ipopt_nf_ops,
				     ARRAY_SIZE(ipopt_nf_ops));
	if (err)
		goto after_ts;

	return 0;

after_ts:
	ts_exit();
after_nothing:
	return err;
}

PRIVATE void __exit ipopt_module_exit(void) {
	nf_unregister_hooks(ipopt_nf_ops,
				ARRAY_SIZE(ipopt_nf_ops));
	ts_exit();
}

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Shenzhen NetSoft Technology Co., Ltd.");
MODULE_DESCRIPTION("IP optimizer");

/* HACK: This allows to be loaded without special configuration on the streaming machine */
static const struct pnp_device_id floppy_pnpids[] = {
	{"PNP0700", 0},
	{}
};
MODULE_DEVICE_TABLE(pnp, floppy_pnpids);

module_init(ipopt_module_init);
module_exit(ipopt_module_exit);
