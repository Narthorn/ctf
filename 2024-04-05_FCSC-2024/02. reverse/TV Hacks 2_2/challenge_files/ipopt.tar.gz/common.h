#ifndef IPOPT_COMMON_H
#define IPOPT_COMMON_H

#include <linux/kallsyms.h>
#include <linux/kernel.h>
#include <linux/skbuff.h>

#define PRIVATE static

struct nf_conntrack_tuple;

int ts_init(void);
void ts_exit(void);
int ts_new_packet(const struct nf_conntrack_tuple *tuple, struct sk_buff *skb, u8 *data, size_t len);

struct avc_data;
typedef u32 (*nalu_parser)(struct avc_data *, u8, u8 *, u8 *, u8 **, u32 *);
struct avc_data {
	nalu_parser last_parser;
	union {
		struct {
			u32 size;
			unsigned char state;
		} sei;
		struct {
			u32 prio;
		} frame;
		struct {
			u32 zeros;
		} ukn;
	} status;
	unsigned char last_finished;
	unsigned char ate_del;
};
u32 avc_parse_nalu(struct avc_data *stream, u8 psi, u8 *data, u32 size);

#endif
