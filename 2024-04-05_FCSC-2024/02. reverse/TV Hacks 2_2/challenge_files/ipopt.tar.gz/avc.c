#include "common.h"
#include "bs.h"

PRIVATE u32 parse_ukn(struct avc_data *stream, u8 begin, u8 *end, u8 *ate_del, u8 **payload, u32 *size) {
	u8 *data = *payload;
	*end = 0;
	*ate_del = 0;
	if (begin) {
		stream->status.ukn.zeros = 0;
	}
	while(*size >= 4) {
		if (*data == 0) {
			if (stream->status.ukn.zeros < 3) {
				stream->status.ukn.zeros++;
			}
		}
		else if ((*data == 1) && 
			(stream->status.ukn.zeros >= 2)) {
				(*size)--;
				data++;
				*payload = data;
				*ate_del = 1;
				*end = 1;
				return 0;
		}
		else {
			stream->status.ukn.zeros = 0;
		}
		(*size)--;
		data++;
	}
	data = data + *size;
	*size = 0;
	*payload = data;
	return 0;
}

PRIVATE u32 parse_fil(struct avc_data *stream, u8 begin, u8 *end, u8 *ate_del, u8 **payload, u32 *size) {
	u8 *data = *payload;
	*end = 0;
	*ate_del = 0;
	while(*size > 1) {
		if (*data != 0xff) {
			*payload = data;
			*end = 1;
			return 0;
		}
		(*size)--;
		data++;
	}
	data = data + *size;
	*size = 0;
	*payload = data;
	return 0;
}

PRIVATE u32 parse_aud(struct avc_data *stream, u8 begin, u8 *end, u8 *ate_del, u8 **payload, u32 *size) {
	*end = 0;
	*ate_del = 0;
	if (*size > 0) {
		*payload = *payload + 1;
		*size = *size - 1;
		*end = 1;
	}
	return 0;
}

PRIVATE u32 parse_iframe(struct avc_data *stream, u8 begin, u8 *end, u8 *ate_del, u8 **payload, u32 *size) {
	*payload = *payload + *size;
	*size = 0;
	*ate_del = 0;
	*end = 0;
	return 3;
}

PRIVATE u32 parse_sei(struct avc_data *stream, u8 begin, u8 *end, u8 *ate_del, u8 **payload, u32 *size) {
	u32 toeat = 0;
	*end = 0;
	*ate_del = 0;
	if (begin) {
		stream->status.sei.size = 0;
		stream->status.sei.state = 0;
	}
	while (*size > 0 && (begin || (**payload & 0x80) != 0x80)) {
		begin = 0;
		while (*size > 0 && **payload == 0xff && stream->status.sei.state == 0) {
			(*size)--;
			(*payload)++;
		}
		if (*size > 0 && stream->status.sei.state == 0) {
			stream->status.sei.state = 1;
			(*size)--;
			(*payload)++;
		}
		while (*size > 0 && **payload == 0xff && stream->status.sei.state == 1) {
			stream->status.sei.size = stream->status.sei.size + 255;
			(*size)--;
			(*payload)++;
		}
		if (*size > 0 && stream->status.sei.state == 1) {
			stream->status.sei.size = stream->status.sei.size + **payload;
			stream->status.sei.state = 2;
			(*size)--;
			(*payload)++;
		}
		if (*size == 0)
			break;
		toeat = min(stream->status.sei.size, *size);
		*payload = *payload + toeat;
		*size = *size - toeat;
		stream->status.sei.size = stream->status.sei.size - toeat;
		if (stream->status.sei.size == 0) {
			stream->status.sei.state = 0;
		}
	}
	if (*size > 0) {
		(*size)--;
		(*payload)++;
		*end = 1;
	}
	return 3;
}

PRIVATE u32 parse_sps(struct avc_data *stream, u8 begin, u8 *end, u8 *ate_del, u8 **payload, u32 *size) {
	parse_ukn(stream, begin, end, ate_del, payload, size);
	return 3;
}

PRIVATE u32 parse_pps(struct avc_data *stream, u8 begin, u8 *end, u8 *ate_del, u8 **payload, u32 *size) {
	parse_ukn(stream, begin, end, ate_del, payload, size);
	return 3;
}

PRIVATE u32 parse_frame(struct avc_data *stream, u8 begin, u8 *end, u8 *ate_del, u8 **payload, u32 *size) {
	bs_t bs;
	int ft;
	if (begin) {
		bs_init(&bs, *payload, *size);
		bs_read_ue(&bs);
		ft = bs_read_ue(&bs);
		switch(ft) {
			case 0:
			case 3:
			case 5:
			case 8:
				/* Frame P */
				stream->status.frame.prio = 2;
				break;
			case 1:
			case 6:
				/* Frame B */
				stream->status.frame.prio = 1;
				break;
			case 2:
			case 4:
			case 7:
			case 9:
				/* Frame I */
				stream->status.frame.prio = 3;
				break;
			default:
				stream->status.frame.prio = 0;
				break;
		}
	}
	*payload = *payload + *size;
	*size = 0;
	*ate_del = 0;
	*end = 0;
	return stream->status.frame.prio;
	
}

u32 avc_parse_nalu(struct avc_data *stream, u8 psi, u8 *data, u32 size) {
	u32 prio = 0;
	u8 nal_header;

	if (psi) {
		stream->last_parser = NULL;
		stream->last_finished = 1;
	} else if (!stream->last_finished) {
		if (stream->last_parser != NULL) {
			prio = max(prio, stream->last_parser(stream, 0, &stream->last_finished, &stream->ate_del, &data, &size));
		}
		else
			return 0;

	}
	while(size >= 5) {
		stream->last_parser = NULL;
		if (!stream->ate_del) {
			if (data[2] != 1 && data[0] == 0) {
				data++;
				size--;
			}
			if (data[0] != 0 ||
				data[1] != 0 || data[2] != 1) {
				/* Error */
				return 0;
			}
			data = data + 3;
			size = size - 3;
		}
		stream->ate_del = 0;
		nal_header = data[0];
		if ((nal_header & 0x80) != 0x00) {
			return 0;
		}
		data++;
		size--;
		switch(nal_header & 0x1f) {
			case 1:
				stream->last_parser = parse_frame;
				break;
			case 5:
				stream->last_parser = parse_iframe;
				break;
			case 6:
				stream->last_parser = parse_sei;
				break;
			case 7:
				stream->last_parser = parse_sps;
				break;
			case 8:
				stream->last_parser = parse_pps;
				break;
			case 9:
				stream->last_parser = parse_aud;
				break;
			case 12:
				stream->last_parser = parse_fil;
				break;
			default:
				stream->last_parser = parse_ukn;
				break;
		}
		if (stream->last_parser != NULL) {
			prio = max(prio, stream->last_parser(stream, 1, &stream->last_finished, &stream->ate_del, &data, &size));
		}
		else
			break;
	}
	return prio;
}
